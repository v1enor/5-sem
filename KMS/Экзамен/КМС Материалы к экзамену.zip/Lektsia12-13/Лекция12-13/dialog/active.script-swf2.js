﻿var dialogOn = false;
//подготовка среды
function prepare_environment(){
//диалоговый модуль
	document.body.innerHTML+="<div id='dialog' class='dialog' style='margin-left:-25px;'>"+
		"<div class='label' onclick='toggleDialog()'>Нажми, чтобы спросить!</div>"+
		"<div class='header'>История:</div>"+
		"<div class='history' id='history'></div>"+
		"<div class='question'><input id='Qdialog' placeholder='Введите вопрос'/><br>"+
		"<button onclick='ask(\"Qdialog\")'>Спросить</button>"
		"</div>"+
	"</div>";
	//крупный план изображений
	document.body.innerHTML+="<div id='imgalert'  style='display:none'>"+
		"<div class='bg' onclick='hide(\"imgalert\")'>&nbsp;</div>"+
		"<img id='img_in_alert' src='' />"+
	"</div>";
}
//ДИАЛОГ
//показ-скрытие диалогового модуля
function toggleDialog(){
	//закрытие
	if(dialogOn){
		$("#dialog").animate({"margin-left":"-25px"}, 1000, function() {});
		dialogOn=false;
	}
	//открытие
	else{
		$("#dialog").animate({"margin-left":"-300px"}, 1000, function() {});
		dialogOn=true;
	}
}

//база знаний
var knowledge = [ 
    [ "измерения ЭДС концентрационных гальванических элементов", 
        "являются", 
        "очень удобным, надёжным и точным методом экспериментального определения " +
                "различных свойств веществ и растворов электролитов" ], 
    [ "схемы материального баланса в электродных пространствах", 
        "можно составить", 
        "пользуясь числами переноса ионов для любых концентрационных элементов "+
                "с переносом" ], 
    [ "электрохимия", 
        "- это", 
        "раздел химической науки, в котором рассматриваются системы и межфазные границы при протекании через них электрического тока, исследуются процессы в проводниках, на электродах (из металлов или полупроводников, включая графит) и в ионных проводниках (электролитах)." ], 

	
	 [ "общий объем программных средств", 
        "рассчитывается", 
        "по формуле: <br><img src='formula/image003.gif'><br>где V<sub>о</sub> – общий объем программного средства, условных машино-команд; <br>V<sub>i</sub> – объем i-ой функции ПС, условных машино-команд;<br>n – общее число функций.<br>" ], 
    [ "правильно разомкнутые гальванические цепи, эквивалентные между собой", 
        "выглядят", 
        "следующим образом: <br><img src='pictures/ris21_23.jpg'>" ], 
	//связь с картинкой в ответе - как выглядит схема измерения ЭДС ГЭ
    [ "схема измерения ЭДС ГЭ компенсационным методом", 
        "показана", 
        "на рисунке: <br><img src='image/chapter3_1/3_1_img1.JPG'/>" ], 
	//связь с картинкой в ответе - как выглядят интегральные и дифференциальные кривые титрования щелочью кислот
    [ "интегральные (а, в) и дифференциальные (б, г) кривые титрования щелочью сильной кислоты (а, б) и смеси сильной и слабой кислот (в, г)", 
        "показаны", 
        "на рисунке: <br><img src='image/chapter3_3/3_3_43_e.JPG'/>" ], 
	//связь с анимацией в ответе - кто является первооткрывателем микробов
    [ "первооткрывателем мира микробов", 
        "считается", 
        "Антони ван Левенгук (Antony van Leeuwenhoek,  1632-1723), который жил в Голландии и занимался, в основном, пошивом одежды: <br><embed src='1a.swf'/>" ],
	["Луна",
	 "является",
	 "спутником Земли"]
];

//поиск и вывод ответа и вопроса
function ask(questionInput){
	var question=document.getElementById(questionInput).value;
	//выдвижение диалогового модуля
	$("#dialog").animate({"margin-left":"-300px"}, 1000, function() {});
	dialogOn=true;
	//вывод вопроса
	document.getElementById("history").innerHTML+="<div class='question'>"+question+"</div>";
	//поиск и вывод ответа
	document.getElementById("history").innerHTML+="<div class='answer'>"+getAnswer(question)+"</div>";
	//прокрутка истории в самый низ
	document.getElementById("history").scrollTop = document.getElementById("history").scrollHeight;
	//очистка текстового поля для ввода вопроса
	document.getElementById(questionInput).value="";
}

//псевдоокончания сказуемых (глаголов, кратких причастий и прилагательных )
var endings = [ ["ет","(ет|ут|ют)"], ["ут","(ет|ут|ют)"], ["ют","(ет|ут|ют)"],//1 спряжение
        ["ит","(ит|ат|ят)"], ["ат","(ит|ат|ят)"], ["ят","(ит|ат|ят)"],//2 спряжение
        ["ется","(ет|ут|ют)ся"], ["утся","(ет|ут|ют)ся"], ["ются","(ет|ут|ют)ся"],//1 спряжение, возвратные
        ["ится","(ит|ат|ят)ся"], ["атся","(ит|ат|ят)ся"], ["ятся","(ит|ат|ят)ся"],//2 спряжение, возвратные
        ["ен","ен"], ["ена","ена"], ["ено","ено"], ["ены","ены"],//краткие прилагательные
        ["ан","ан"], ["ана","ана"], ["ано","ано"], ["аны","аны"],//краткие прилагательные
        ["жен","жен"], ["жна","жна"], ["жно","жно"], ["жны","жны"],//краткие прилагательные
		["такое","- это"]];//для вопроса "что такое А?" ответ - "А - это ..."
//черный список слов, распознаваемых как сказуемые по ошибке
var blacklist = [ "замена", "замены", "атрибут", "маршрут", "член", "нет" ];
//функция определения сказуемых по соответствующим псевдоокончаниям
function getEnding(word)
{
    //проверка по черному списку
    if (blacklist.indexOf(word)!==-1) return -1;
    //перебор псевдоокончаний
    for (var j = 0; j < endings.length; j++)
    {
		
        //проверка, оканчивается ли i-ое слово на j-ое псевдоокончание
        if(word.substring(word.length-endings[j][0].length)==endings[j][0]){
            return j;   //возврат номера псевдоокончания
        }
    }
    return -1;  //если совпадений нет - возврат -1
}

//функция, которая делает первую букву маленькой
function small1(str)
{
    return str.substring(0, 1).toLowerCase() + str.substring(1);
}
//функция, которая делает первую букву большой
function big1(str)
{
    return str.substring(0, 1).toUpperCase() + str.substring(1);
}


//главная функция, обрабатывающая запросы клиентов
function getAnswer(question)
{
    //знаки препинания
    var separators = "'\",.!?()[]\\/";
    //получение текста из параметра запроса
    var txt = small1(question);
    //добавление пробелов перед знаками препинания
    for (var i = 0; i < separators.length; i++)
       txt = txt.replace(separators[i], " " + separators[i]);
    //массив слов и знаков препинания
    var words = txt.split(' ');
    //флаг, найден ли ответ
    var result = false;
    //формируемый функцией ответ на вопрос
    var answer="";
    //перебор слов
    for (var i = 0; i < words.length; i++)
    {
		//поиск номера псевдоокончания 
        var ending = getEnding(words[i]);
		
        //если псевдоокончание найдено – это сказуемое, подлежащее в вопросе после него
        if (ending >= 0)
        {
            //замена псевдоокончания на набор возможных окончаний
            words[i] = words[i].substring(0, words[i].length -
                endings[ending][0].length) + endings[ending][1];
            //создание регулярного выражения для поиска по сказуемому из вопроса
            var predicate = new RegExp(words[i]);
            //для кратких прилагательных захватываем следующее слово
            if (endings[ending][0] == endings[ending][1])
            {
                predicate = new RegExp(words[i] + " " + words[i + 1]);
                i++;
            }
            //создание регулярного выражения для поиска по подлежащему из вопроса
			var subject_string = words.slice(i + 1).join(".*");
			//только если в послежащем больше трех символов
			if (subject_string.length>3)
			{
				var subject = new RegExp(".*" +
					subject_string +
					".*");
				//поиск совпадений с шаблонами среди связей семантической сети
				for (var j = 0; j < knowledge.length; j++)
				{
					if (predicate.test(knowledge[j][1]) &&
						(subject.test(knowledge[j][0]) ||
							subject.test(knowledge[j][2])))
					{
						//создание простого предложения из семантической связи
						answer+=big1(knowledge[j][0] + " " +
							knowledge[j][1] + " " + knowledge[j][2] + ". ");
						result = true;
					}
				}
				//если совпадений с двумя шаблонами нет,
				if (result == false){
					//поиск совпадений только с шаблоном подлежащего
					for (var j = 0; j < knowledge.length; j++)
					{
						if ((subject.test(knowledge[j][0]) ||
								subject.test(knowledge[j][2])))
						{
							//создание простого предложения из семантической связи
							answer+=big1(knowledge[j][0] + " " +
								knowledge[j][1] + " " + knowledge[j][2] + ". ");
							result = true;
						}
					}
				}
			}
        }
    }
    //если ответа нет
    if(!result)
    	answer = "Ответ не найден. <br/>";
	//если ответ есть - добавляем увеличение картинок
	else
		answer = answer.replace("<img ", "<img onclick='zoom(this.src)'");
    return answer;
}

function zoom(src){
	document.getElementById("img_in_alert").src=src;
	$("#imgalert").css({"display":"block"});
	clearInterval(timer);
}

